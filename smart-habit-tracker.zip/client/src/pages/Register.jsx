import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { User, Mail, Lock } from "lucide-react"
import { useAuth } from "../context/AuthContext.jsx"
import { AuthShell, Field } from "./Login.jsx"

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: "", email: "", password: "" })
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    if (form.password.length < 6) {
      setError("Password must be at least 6 characters")
      return
    }
    setLoading(true)
    try {
      await register(form.name, form.email, form.password)
      navigate("/")
    } catch (err) {
      setError(err.response?.data?.message || "Unable to create account")
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthShell
      title="Create your account"
      subtitle="Start building better habits today"
      footer={
        <>
          Already have an account?{" "}
          <Link to="/login" className="font-semibold text-brand-blue hover:underline">
            Log in
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Field
          icon={User}
          type="text"
          placeholder="Your name"
          value={form.name}
          onChange={(v) => setForm({ ...form, name: v })}
          autoComplete="name"
        />
        <Field
          icon={Mail}
          type="email"
          placeholder="you@student.edu"
          value={form.email}
          onChange={(v) => setForm({ ...form, email: v })}
          autoComplete="email"
        />
        <Field
          icon={Lock}
          type="password"
          placeholder="Password (min 6 characters)"
          value={form.password}
          onChange={(v) => setForm({ ...form, password: v })}
          autoComplete="new-password"
        />

        {error && <p className="text-sm text-red-500">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="mt-1 rounded-xl bg-gradient-to-r from-brand-blue via-brand-purple to-brand-green py-2.5 text-sm font-semibold text-white shadow-sm transition hover:opacity-90 disabled:opacity-60"
        >
          {loading ? "Creating account..." : "Sign up"}
        </button>
      </form>
    </AuthShell>
  )
}
