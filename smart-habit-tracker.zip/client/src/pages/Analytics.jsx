import { useEffect, useState } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  CartesianGrid,
} from "recharts"
import { Loader2, TrendingUp, CalendarCheck, Percent } from "lucide-react"
import api from "../api/client.js"
import StatCard from "../components/StatCard.jsx"
import { MOOD_MAP, COLOR_STYLES, HABIT_ICONS } from "../lib/constants.js"
import { useTheme } from "../context/ThemeContext.jsx"

export default function Analytics() {
  const { theme } = useTheme()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api
      .get("/analytics/weekly")
      .then((res) => setData(res.data))
      .catch((err) => console.error("[analytics] load failed:", err.message))
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand-blue" />
      </div>
    )
  }

  if (!data) {
    return <p className="text-slate-500">Could not load analytics.</p>
  }

  const axisColor = theme === "dark" ? "#94a3b8" : "#64748b"
  const gridColor = theme === "dark" ? "#1e293b" : "#e2e8f0"
  const tooltipStyle = {
    backgroundColor: theme === "dark" ? "#0f172a" : "#ffffff",
    border: `1px solid ${gridColor}`,
    borderRadius: 12,
    fontSize: 13,
    color: theme === "dark" ? "#e2e8f0" : "#1e293b",
  }

  const moodData = data.moodDistribution
    .filter((m) => m.count > 0)
    .map((m) => ({ ...m, name: MOOD_MAP[m.mood].label, color: MOOD_MAP[m.mood].color }))

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-800 dark:text-slate-100">
          Analytics
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Your progress over the last 7 days
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          icon={CalendarCheck}
          label="Completions this week"
          value={data.summary.totalCompletionsThisWeek}
          sublabel="habit check-ins"
          accent="green"
        />
        <StatCard
          icon={Percent}
          label="Weekly completion rate"
          value={`${data.summary.weeklyRate}%`}
          sublabel="of all possible check-ins"
          accent="blue"
        />
        <StatCard
          icon={TrendingUp}
          label="Habits tracked"
          value={data.summary.totalHabits}
          sublabel="active this week"
          accent="purple"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Weekly completion bar chart */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
          <h2 className="font-semibold text-slate-800 dark:text-slate-100">Weekly habit completion</h2>
          <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
            Habits completed each day
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.weeklyCompletion} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4f7cff" />
                    <stop offset="100%" stopColor="#8b5cf6" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                <XAxis dataKey="label" tick={{ fill: axisColor, fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} tick={{ fill: axisColor, fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: `${gridColor}55` }} />
                <Bar dataKey="completed" fill="url(#barGradient)" radius={[6, 6, 0, 0]} maxBarSize={44} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mood distribution pie chart */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-semibold text-slate-800 dark:text-slate-100">Mood distribution</h2>
          <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">How you felt this week</p>
          <div className="h-64">
            {moodData.length === 0 ? (
              <div className="flex h-full items-center justify-center text-center text-sm text-slate-400">
                No moods logged yet
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={moodData}
                    dataKey="count"
                    nameKey="name"
                    innerRadius={45}
                    outerRadius={80}
                    paddingAngle={3}
                  >
                    {moodData.map((entry) => (
                      <Cell key={entry.mood} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend
                    iconType="circle"
                    wrapperStyle={{ fontSize: 12, color: axisColor }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Habit-wise statistics */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <h2 className="font-semibold text-slate-800 dark:text-slate-100">Habit-wise statistics</h2>
        <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
          Completion breakdown per habit
        </p>

        {data.habitStats.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">No habits to analyze yet.</p>
        ) : (
          <div className="flex flex-col gap-3">
            {data.habitStats.map((h) => {
              const color = COLOR_STYLES[h.color] || COLOR_STYLES.blue
              const Icon = HABIT_ICONS[h.icon] || HABIT_ICONS.target
              return (
                <div
                  key={h.id}
                  className="flex flex-col gap-3 rounded-xl border border-slate-100 p-3 dark:border-slate-800 sm:flex-row sm:items-center"
                >
                  <div className="flex min-w-0 flex-1 items-center gap-3">
                    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${color.bg} ${color.text}`}>
                      <Icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-800 dark:text-slate-100">{h.name}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {h.weekCompletions}/7 this week · {h.totalCompletions} all-time
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="hidden w-40 sm:block">
                      <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                        <div className={`h-full rounded-full ${color.dot}`} style={{ width: `${h.completionRate}%` }} />
                      </div>
                    </div>
                    <span className="w-12 text-right text-sm font-semibold text-slate-700 dark:text-slate-200">
                      {h.completionRate}%
                    </span>
                    <span className="flex items-center gap-1 text-sm text-orange-500">
                      {h.currentStreak}
                      <span className="text-xs text-slate-400">streak</span>
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
