import { useEffect, useState } from "react"
import { Plus, Flame, Trophy, Target, CheckCircle2, Loader2 } from "lucide-react"
import api from "../api/client.js"
import StatCard from "../components/StatCard.jsx"
import HabitCard from "../components/HabitCard.jsx"
import HabitModal from "../components/HabitModal.jsx"
import MoodSelector from "../components/MoodSelector.jsx"

export default function Dashboard() {
  const [habits, setHabits] = useState([])
  const [mood, setMood] = useState(null)
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [saving, setSaving] = useState(false)
  const [togglingId, setTogglingId] = useState(null)
  const [moodBusy, setMoodBusy] = useState(false)

  const loadData = async () => {
    try {
      const [habitsRes, moodRes] = await Promise.all([
        api.get("/habits"),
        api.get("/mood/week"),
      ])
      setHabits(habitsRes.data.habits)
      setMood(moodRes.data.today)
    } catch (err) {
      console.error("[dashboard] load failed:", err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  const handleToggle = async (habit) => {
    setTogglingId(habit.id)
    try {
      await api.post("/logs/toggle", { habitId: habit.id })
      await loadData()
    } catch (err) {
      console.error("[dashboard] toggle failed:", err.message)
    } finally {
      setTogglingId(null)
    }
  }

  const handleSave = async (form) => {
    setSaving(true)
    try {
      if (editing) {
        await api.put(`/habits/${editing.id}`, form)
      } else {
        await api.post("/habits", form)
      }
      setModalOpen(false)
      setEditing(null)
      await loadData()
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (habit) => {
    if (!window.confirm(`Delete "${habit.name}"? This removes its history too.`)) return
    try {
      await api.delete(`/habits/${habit.id}`)
      await loadData()
    } catch (err) {
      console.error("[dashboard] delete failed:", err.message)
    }
  }

  const handleMood = async (key) => {
    setMoodBusy(true)
    const previous = mood
    setMood(key)
    try {
      await api.post("/mood", { mood: key })
    } catch (err) {
      console.error("[dashboard] mood failed:", err.message)
      setMood(previous)
    } finally {
      setMoodBusy(false)
    }
  }

  const completedToday = habits.filter((h) => h.completedToday).length
  const bestStreak = habits.reduce((m, h) => Math.max(m, h.bestStreak), 0)
  const currentStreak = habits.reduce((m, h) => Math.max(m, h.currentStreak), 0)
  const todayRate = habits.length ? Math.round((completedToday / habits.length) * 100) : 0

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand-blue" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-800 dark:text-slate-100">
            Today&apos;s habits
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <button
          onClick={() => {
            setEditing(null)
            setModalOpen(true)
          }}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-blue to-brand-purple px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:opacity-90"
        >
          <Plus className="h-4 w-4" />
          New habit
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          icon={CheckCircle2}
          label="Done today"
          value={`${completedToday}/${habits.length}`}
          sublabel={`${todayRate}% of today complete`}
          accent="green"
        />
        <StatCard
          icon={Flame}
          label="Current streak"
          value={currentStreak}
          sublabel="days in a row"
          accent="blue"
        />
        <StatCard
          icon={Trophy}
          label="Best streak"
          value={bestStreak}
          sublabel="all-time record"
          accent="amber"
        />
        <StatCard
          icon={Target}
          label="Active habits"
          value={habits.length}
          sublabel="being tracked"
          accent="purple"
        />
      </div>

      <MoodSelector value={mood} onSelect={handleMood} busy={moodBusy} />

      {habits.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-blue/10 text-brand-blue">
            <Target className="h-6 w-6" />
          </span>
          <h3 className="mt-3 font-semibold text-slate-800 dark:text-slate-100">No habits yet</h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Add your first habit to start tracking your progress.
          </p>
          <button
            onClick={() => {
              setEditing(null)
              setModalOpen(true)
            }}
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-blue to-brand-purple px-4 py-2.5 text-sm font-semibold text-white"
          >
            <Plus className="h-4 w-4" />
            Add a habit
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {habits.map((habit) => (
            <HabitCard
              key={habit.id}
              habit={habit}
              busy={togglingId === habit.id}
              onToggle={handleToggle}
              onEdit={(h) => {
                setEditing(h)
                setModalOpen(true)
              }}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <HabitModal
        open={modalOpen}
        habit={editing}
        saving={saving}
        onClose={() => {
          setModalOpen(false)
          setEditing(null)
        }}
        onSave={handleSave}
      />
    </div>
  )
}
