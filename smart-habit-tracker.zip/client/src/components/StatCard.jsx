export default function StatCard({ icon: Icon, label, value, sublabel, accent = "blue" }) {
  const accents = {
    blue: "from-brand-blue/15 to-brand-blue/5 text-brand-blue",
    purple: "from-brand-purple/15 to-brand-purple/5 text-brand-purple",
    green: "from-brand-green/15 to-brand-green/5 text-brand-green",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-500",
  }

  return (
    <div className="animate-fade-up rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</span>
        <span
          className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${accents[accent]}`}
        >
          <Icon className="h-5 w-5" />
        </span>
      </div>
      <p className="mt-3 text-3xl font-extrabold tracking-tight text-slate-800 dark:text-slate-100">
        {value}
      </p>
      {sublabel && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{sublabel}</p>}
    </div>
  )
}
