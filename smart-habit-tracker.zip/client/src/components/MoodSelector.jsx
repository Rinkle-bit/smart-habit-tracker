import { MOODS } from "../lib/constants.js"

export default function MoodSelector({ value, onSelect, busy }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-slate-800 dark:text-slate-100">How are you feeling today?</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Log one mood each day</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-2 sm:gap-3">
        {MOODS.map((mood) => {
          const active = value === mood.key
          return (
            <button
              key={mood.key}
              onClick={() => onSelect(mood.key)}
              disabled={busy}
              className={`flex flex-col items-center gap-1.5 rounded-xl border py-3 transition disabled:opacity-60 ${
                active
                  ? "border-transparent text-white shadow-sm"
                  : "border-slate-200 hover:border-slate-300 dark:border-slate-700 dark:hover:border-slate-600"
              }`}
              style={active ? { backgroundColor: mood.color } : undefined}
              aria-pressed={active}
            >
              <span className="text-2xl" aria-hidden="true">
                {mood.emoji}
              </span>
              <span
                className={`text-xs font-medium ${
                  active ? "text-white" : "text-slate-600 dark:text-slate-300"
                }`}
              >
                {mood.label}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
