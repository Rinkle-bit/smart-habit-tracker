import { Check, Flame, Pencil, Trash2, Trophy } from "lucide-react"
import { HABIT_ICONS, COLOR_STYLES } from "../lib/constants.js"

export default function HabitCard({ habit, onToggle, onEdit, onDelete, busy }) {
  const Icon = HABIT_ICONS[habit.icon] || HABIT_ICONS.target
  const color = COLOR_STYLES[habit.color] || COLOR_STYLES.blue

  return (
    <div className="group animate-fade-up rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${color.bg} ${color.text}`}>
            <Icon className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3 className="truncate font-semibold text-slate-800 dark:text-slate-100">{habit.name}</h3>
            {habit.description && (
              <p className="truncate text-sm text-slate-500 dark:text-slate-400">{habit.description}</p>
            )}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100">
          <button
            onClick={() => onEdit(habit)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
            aria-label={`Edit ${habit.name}`}
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            onClick={() => onDelete(habit)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10"
            aria-label={`Delete ${habit.name}`}
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="mt-4 flex items-center gap-4 text-sm">
        <span className="flex items-center gap-1.5 text-orange-500">
          <Flame className="h-4 w-4" />
          <span className="font-semibold">{habit.currentStreak}</span>
          <span className="text-slate-400">streak</span>
        </span>
        <span className="flex items-center gap-1.5 text-amber-500">
          <Trophy className="h-4 w-4" />
          <span className="font-semibold">{habit.bestStreak}</span>
          <span className="text-slate-400">best</span>
        </span>
      </div>

      <div className="mt-3">
        <div className="mb-1 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>Completion</span>
          <span className="font-medium">{habit.completionRate}%</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
          <div
            className={`h-full rounded-full ${color.dot}`}
            style={{ width: `${habit.completionRate}%` }}
          />
        </div>
      </div>

      <button
        onClick={() => onToggle(habit)}
        disabled={busy}
        className={`mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition disabled:opacity-60 ${
          habit.completedToday
            ? "bg-gradient-to-r from-brand-blue to-brand-green text-white shadow-sm"
            : "border border-slate-200 text-slate-600 hover:border-brand-blue hover:text-brand-blue dark:border-slate-700 dark:text-slate-300"
        }`}
      >
        <Check className="h-4 w-4" />
        {habit.completedToday ? "Completed today" : "Mark as done"}
      </button>
    </div>
  )
}
