import { useEffect, useState } from "react"
import { X } from "lucide-react"
import {
  HABIT_ICONS,
  ICON_OPTIONS,
  COLOR_STYLES,
  COLOR_OPTIONS,
} from "../lib/constants.js"

const EMPTY = { name: "", description: "", icon: "target", color: "blue" }

export default function HabitModal({ open, habit, onClose, onSave, saving }) {
  const [form, setForm] = useState(EMPTY)
  const [error, setError] = useState("")

  useEffect(() => {
    if (open) {
      setForm(
        habit
          ? {
              name: habit.name,
              description: habit.description || "",
              icon: habit.icon,
              color: habit.color,
            }
          : EMPTY
      )
      setError("")
    }
  }, [open, habit])

  if (!open) return null

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.name.trim()) {
      setError("Please enter a habit name")
      return
    }
    try {
      await onSave(form)
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong")
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-4 backdrop-blur-sm sm:items-center">
      <div className="w-full max-w-md animate-fade-up rounded-2xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">
            {habit ? "Edit habit" : "New habit"}
          </h2>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-4">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
              Habit name
            </label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Study 2 hours"
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              autoFocus
            />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
              Description <span className="text-slate-400">(optional)</span>
            </label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="A short note to keep you motivated"
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300">Icon</label>
            <div className="grid grid-cols-6 gap-2">
              {ICON_OPTIONS.map((name) => {
                const Icon = HABIT_ICONS[name]
                const active = form.icon === name
                return (
                  <button
                    type="button"
                    key={name}
                    onClick={() => setForm({ ...form, icon: name })}
                    className={`flex aspect-square items-center justify-center rounded-xl border transition ${
                      active
                        ? "border-brand-blue bg-brand-blue/10 text-brand-blue"
                        : "border-slate-200 text-slate-500 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
                    }`}
                    aria-label={name}
                  >
                    <Icon className="h-5 w-5" />
                  </button>
                )
              })}
            </div>
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300">Color</label>
            <div className="flex gap-2">
              {COLOR_OPTIONS.map((name) => {
                const active = form.color === name
                return (
                  <button
                    type="button"
                    key={name}
                    onClick={() => setForm({ ...form, color: name })}
                    className={`h-8 w-8 rounded-full ${COLOR_STYLES[name].dot} ring-offset-2 transition dark:ring-offset-slate-900 ${
                      active ? "ring-2 ring-slate-400" : ""
                    }`}
                    aria-label={name}
                  />
                )
              })}
            </div>
          </div>

          {error && <p className="text-sm text-red-500">{error}</p>}

          <div className="mt-1 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 rounded-xl bg-gradient-to-r from-brand-blue to-brand-purple py-2.5 text-sm font-semibold text-white shadow-sm transition hover:opacity-90 disabled:opacity-60"
            >
              {saving ? "Saving..." : habit ? "Save changes" : "Add habit"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
