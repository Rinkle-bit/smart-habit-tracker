# Momentum — MERN Habit & Mood Tracker

A full-stack MERN application for tracking daily habits, logging moods, and visualizing
progress over time. Built as a classic separated **Vite + React** frontend and
**Express + MongoDB (Mongoose)** backend, with custom JWT authentication.

## Features

- **JWT auth** — register / login with bcrypt-hashed passwords
- **Habit management** — create, edit, archive, and delete habits with color, icon, and target frequency
- **Daily check-ins** — toggle habit completion for any day
- **Streaks** — current and longest streak computed per habit
- **Mood journal** — log a daily mood (1–5) with an optional note
- **Analytics** — completion-rate charts, mood trends, and habit heatmaps (Recharts)
- **Dark / light theme** — persisted to `localStorage`
- **Seed script** — generates a demo user with realistic history

## Project structure

```
.
├── client/          # Vite + React frontend
│   ├── src/
│   │   ├── api/         # axios instance
│   │   ├── components/  # UI + layout components
│   │   ├── context/     # Auth + Theme providers
│   │   ├── lib/         # shared constants
│   │   └── pages/       # Login, Register, Dashboard, Analytics
│   └── vite.config.js
└── server/          # Express + Mongoose backend
    ├── config/         # Mongo connection
    ├── controllers/    # route handlers
    ├── middleware/     # JWT auth guard
    ├── models/         # User, Habit, HabitLog, Mood
    ├── routes/         # /api/* routers
    ├── utils/          # date + stats helpers
    ├── seed.js
    └── server.js
```

## Getting started

> This app uses two separate dev servers and a MongoDB Atlas database, so it runs
> locally rather than inside the v0 preview.

### 1. Backend

```bash
cd server
cp .env.example .env       # fill in MONGODB_URI and JWT_SECRET
npm install
npm run seed               # optional: demo data (demo@momentum.app / password123)
npm run dev                # http://localhost:5000
```

### 2. Frontend

```bash
cd client
cp .env.example .env       # VITE_API_URL defaults to http://localhost:5000/api
npm install
npm run dev                # http://localhost:5173
```

### Run both from the root

```bash
npm install                # installs concurrently
npm run dev                # runs client + server together
```

## Environment variables

**server/.env**

| Key           | Description                                  |
| ------------- | -------------------------------------------- |
| `MONGODB_URI` | MongoDB Atlas connection string              |
| `JWT_SECRET`  | Secret used to sign JWTs                      |
| `JWT_EXPIRES` | Token lifetime (e.g. `7d`)                   |
| `PORT`        | Backend port (default `5000`)                |
| `CLIENT_URL`  | Allowed CORS origin (default Vite dev URL)   |

**client/.env**

| Key            | Description                                       |
| -------------- | ------------------------------------------------- |
| `VITE_API_URL` | Backend base URL (default `http://localhost:5000/api`) |

## API overview

| Method | Endpoint                     | Description                     |
| ------ | ---------------------------- | ------------------------------- |
| POST   | `/api/auth/register`         | Create account                  |
| POST   | `/api/auth/login`            | Log in                          |
| GET    | `/api/auth/me`               | Current user                    |
| GET    | `/api/habits`                | List habits (with stats)        |
| POST   | `/api/habits`                | Create habit                    |
| PUT    | `/api/habits/:id`            | Update habit                    |
| DELETE | `/api/habits/:id`            | Delete habit                    |
| POST   | `/api/logs/toggle`           | Toggle a habit for a date       |
| GET    | `/api/moods`                 | List mood entries               |
| POST   | `/api/moods`                 | Upsert today's mood             |
| GET    | `/api/analytics/overview`    | Aggregated analytics            |
