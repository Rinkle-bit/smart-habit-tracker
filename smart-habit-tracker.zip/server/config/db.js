import mongoose from "mongoose"

export async function connectDB() {
  const uri = process.env.MONGODB_URI
  if (!uri) {
    console.error("[db] MONGODB_URI is not set. Copy .env.example to .env and fill it in.")
    process.exit(1)
  }

  try {
    mongoose.set("strictQuery", true)
    const conn = await mongoose.connect(uri)
    console.log(`[db] MongoDB connected: ${conn.connection.host}`)
  } catch (err) {
    console.error("[db] MongoDB connection error:", err.message)
    process.exit(1)
  }
}
