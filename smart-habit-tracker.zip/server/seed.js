import "dotenv/config"
import mongoose from "mongoose"

import { connectDB } from "./config/db.js"
import User from "./models/User.js"
import Habit from "./models/Habit.js"
import HabitLog from "./models/HabitLog.js"
import Mood, { MOODS } from "./models/Mood.js"
import { lastNDateKeys } from "./utils/date.js"

const DEMO_EMAIL = "demo@student.edu"

const DEMO_HABITS = [
  { name: "Attend all lectures", description: "Show up on time and take notes", icon: "book-open", color: "blue" },
  { name: "Study 2 hours", description: "Focused study session, no phone", icon: "graduation-cap", color: "purple" },
  { name: "Drink 8 glasses of water", description: "Stay hydrated through the day", icon: "droplet", color: "cyan" },
  { name: "Exercise 30 min", description: "Gym, run, or a home workout", icon: "dumbbell", color: "green" },
  { name: "Sleep by 12 AM", description: "No late-night scrolling", icon: "moon", color: "indigo" },
  { name: "Read for fun", description: "At least 10 pages", icon: "book", color: "amber" },
]

async function seed() {
  await connectDB()

  console.log("[seed] Clearing existing demo data...")
  const existing = await User.findOne({ email: DEMO_EMAIL })
  if (existing) {
    await Promise.all([
      Habit.deleteMany({ user: existing._id }),
      HabitLog.deleteMany({ user: existing._id }),
      Mood.deleteMany({ user: existing._id }),
      User.deleteOne({ _id: existing._id }),
    ])
  }

  console.log("[seed] Creating demo user (demo@student.edu / password123)...")
  const user = await User.create({
    name: "Demo Student",
    email: DEMO_EMAIL,
    password: "password123",
  })

  console.log("[seed] Creating demo habits...")
  const habits = await Habit.create(
    DEMO_HABITS.map((h) => ({ ...h, user: user._id }))
  )

  console.log("[seed] Generating 14 days of habit logs...")
  const dayKeys = lastNDateKeys(14)
  const logs = []
  for (const habit of habits) {
    for (const date of dayKeys) {
      // ~70% chance a habit was completed on a given day for realistic streaks
      if (Math.random() < 0.7) {
        logs.push({ user: user._id, habit: habit._id, date, completed: true })
      }
    }
  }
  await HabitLog.insertMany(logs, { ordered: false }).catch(() => {})

  console.log("[seed] Generating mood history...")
  const moodDocs = dayKeys.map((date) => ({
    user: user._id,
    date,
    mood: MOODS[Math.floor(Math.random() * MOODS.length)],
  }))
  await Mood.insertMany(moodDocs, { ordered: false }).catch(() => {})

  console.log("\n[seed] Done!")
  console.log("  Login with: demo@student.edu / password123")
  console.log(`  Habits: ${habits.length}, Logs: ${logs.length}, Moods: ${moodDocs.length}`)

  await mongoose.connection.close()
  process.exit(0)
}

seed().catch((err) => {
  console.error("[seed] Failed:", err)
  process.exit(1)
})
