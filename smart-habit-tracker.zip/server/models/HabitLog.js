import mongoose from "mongoose"

// A log represents a habit being completed on a specific calendar day.
// `date` is stored as a normalized "YYYY-MM-DD" string for easy per-day uniqueness.
const habitLogSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    habit: { type: mongoose.Schema.Types.ObjectId, ref: "Habit", required: true, index: true },
    date: { type: String, required: true }, // YYYY-MM-DD
    completed: { type: Boolean, default: true },
  },
  { timestamps: true }
)

// One log per habit per day
habitLogSchema.index({ habit: 1, date: 1 }, { unique: true })

export default mongoose.model("HabitLog", habitLogSchema)
