import mongoose from "mongoose"

export const MOODS = ["happy", "normal", "sad", "tired"]

const moodSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    mood: { type: String, enum: MOODS, required: true },
    date: { type: String, required: true }, // YYYY-MM-DD
  },
  { timestamps: true }
)

// One mood per user per day (upsert on change)
moodSchema.index({ user: 1, date: 1 }, { unique: true })

export default mongoose.model("Mood", moodSchema)
