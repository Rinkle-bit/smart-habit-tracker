import mongoose from "mongoose"

const habitSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    name: { type: String, required: true, trim: true },
    description: { type: String, default: "", trim: true },
    icon: { type: String, default: "target" },
    color: { type: String, default: "blue" },
    // day of week reminders are not required for MVP; kept simple
    archived: { type: Boolean, default: false },
  },
  { timestamps: true }
)

export default mongoose.model("Habit", habitSchema)
