import { toDateKey } from "./date.js"

// Given a set of completed date keys ("YYYY-MM-DD"), compute streaks.
// currentStreak counts consecutive days up to today (or yesterday if today not done yet).
// bestStreak is the longest run of consecutive completed days ever.
export function computeStreaks(dateKeySet) {
  const sorted = Array.from(dateKeySet).sort()
  if (sorted.length === 0) return { currentStreak: 0, bestStreak: 0 }

  // Best streak
  let best = 1
  let run = 1
  for (let i = 1; i < sorted.length; i++) {
    if (isNextDay(sorted[i - 1], sorted[i])) {
      run += 1
    } else {
      run = 1
    }
    if (run > best) best = run
  }

  // Current streak: walk backwards from today
  let current = 0
  const today = toDateKey()
  const yesterday = shiftKey(today, -1)

  let cursor
  if (dateKeySet.has(today)) {
    cursor = today
  } else if (dateKeySet.has(yesterday)) {
    cursor = yesterday
  } else {
    return { currentStreak: 0, bestStreak: best }
  }

  while (dateKeySet.has(cursor)) {
    current += 1
    cursor = shiftKey(cursor, -1)
  }

  return { currentStreak: current, bestStreak: best }
}

function isNextDay(a, b) {
  return shiftKey(a, 1) === b
}

function shiftKey(key, deltaDays) {
  const d = new Date(`${key}T00:00:00`)
  d.setDate(d.getDate() + deltaDays)
  return toDateKey(d)
}
