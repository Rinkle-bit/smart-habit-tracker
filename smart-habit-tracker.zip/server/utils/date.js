// Normalize a Date to a "YYYY-MM-DD" string (UTC-safe for consistent day keys)
export function toDateKey(date = new Date()) {
  const d = new Date(date)
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${year}-${month}-${day}`
}

// Return an array of the last N date keys, oldest first, ending today.
export function lastNDateKeys(n) {
  const keys = []
  const today = new Date()
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(today)
    d.setDate(today.getDate() - i)
    keys.push(toDateKey(d))
  }
  return keys
}

// Short weekday label (Mon, Tue, ...) for a date key
export function weekdayLabel(dateKey) {
  const d = new Date(`${dateKey}T00:00:00`)
  return d.toLocaleDateString("en-US", { weekday: "short" })
}
