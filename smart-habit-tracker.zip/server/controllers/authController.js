import jwt from "jsonwebtoken"
import User from "../models/User.js"

function signToken(id) {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  })
}

function publicUser(user) {
  return { id: user._id, name: user.name, email: user.email }
}

// POST /api/auth/register
export async function register(req, res) {
  try {
    const { name, email, password } = req.body
    if (!name || !email || !password) {
      return res.status(400).json({ message: "Name, email and password are required" })
    }
    if (password.length < 6) {
      return res.status(400).json({ message: "Password must be at least 6 characters" })
    }

    const existing = await User.findOne({ email: email.toLowerCase() })
    if (existing) {
      return res.status(409).json({ message: "An account with this email already exists" })
    }

    const user = await User.create({ name, email, password })
    const token = signToken(user._id)
    return res.status(201).json({ token, user: publicUser(user) })
  } catch (err) {
    console.error("[auth] register error:", err.message)
    return res.status(500).json({ message: "Server error during registration" })
  }
}

// POST /api/auth/login
export async function login(req, res) {
  try {
    const { email, password } = req.body
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" })
    }

    const user = await User.findOne({ email: email.toLowerCase() }).select("+password")
    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" })
    }

    const match = await user.comparePassword(password)
    if (!match) {
      return res.status(401).json({ message: "Invalid email or password" })
    }

    const token = signToken(user._id)
    return res.json({ token, user: publicUser(user) })
  } catch (err) {
    console.error("[auth] login error:", err.message)
    return res.status(500).json({ message: "Server error during login" })
  }
}

// GET /api/auth/me
export async function me(req, res) {
  try {
    const user = await User.findById(req.userId)
    if (!user) return res.status(404).json({ message: "User not found" })
    return res.json({ user: publicUser(user) })
  } catch (err) {
    console.error("[auth] me error:", err.message)
    return res.status(500).json({ message: "Server error" })
  }
}
