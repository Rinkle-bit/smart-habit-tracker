import Habit from "../models/Habit.js"
import HabitLog from "../models/HabitLog.js"
import { toDateKey } from "../utils/date.js"

// POST /api/logs/toggle  { habitId, date? }
// Toggles completion for a habit on a given day (defaults to today).
export async function toggleLog(req, res) {
  try {
    const { habitId } = req.body
    const date = req.body.date || toDateKey()
    if (!habitId) return res.status(400).json({ message: "habitId is required" })

    const habit = await Habit.findOne({ _id: habitId, user: req.userId })
    if (!habit) return res.status(404).json({ message: "Habit not found" })

    const existing = await HabitLog.findOne({ habit: habitId, user: req.userId, date })

    if (existing) {
      await existing.deleteOne()
      return res.json({ habitId, date, completed: false })
    }

    await HabitLog.create({ habit: habitId, user: req.userId, date, completed: true })
    return res.json({ habitId, date, completed: true })
  } catch (err) {
    console.error("[logs] toggleLog error:", err.message)
    return res.status(500).json({ message: "Server error toggling habit" })
  }
}
