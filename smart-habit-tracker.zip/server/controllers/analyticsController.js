import Habit from "../models/Habit.js"
import HabitLog from "../models/HabitLog.js"
import Mood, { MOODS } from "../models/Mood.js"
import { lastNDateKeys, weekdayLabel } from "../utils/date.js"
import { computeStreaks } from "../utils/stats.js"

// GET /api/analytics/weekly
// Aggregates data for the Analytics page:
//   - weeklyCompletion: completions per day for the last 7 days
//   - moodDistribution: count of each mood over the last 7 days
//   - habitStats: per-habit completion counts, rate, and streaks
export async function getWeeklyAnalytics(req, res) {
  try {
    const weekKeys = lastNDateKeys(7)
    const habits = await Habit.find({ user: req.userId, archived: false }).sort({ createdAt: 1 })
    const totalHabits = habits.length

    const logs = await HabitLog.find({ user: req.userId, completed: true })

    // ---- Weekly completion bar chart ----
    const perDayCount = new Map(weekKeys.map((k) => [k, 0]))
    for (const log of logs) {
      if (perDayCount.has(log.date)) {
        perDayCount.set(log.date, perDayCount.get(log.date) + 1)
      }
    }
    const weeklyCompletion = weekKeys.map((date) => ({
      date,
      label: weekdayLabel(date),
      completed: perDayCount.get(date),
      total: totalHabits,
    }))

    // ---- Mood distribution pie chart (last 7 days) ----
    const moods = await Mood.find({ user: req.userId, date: { $in: weekKeys } })
    const moodCount = Object.fromEntries(MOODS.map((m) => [m, 0]))
    for (const m of moods) moodCount[m.mood] = (moodCount[m.mood] || 0) + 1
    const moodDistribution = MOODS.map((mood) => ({ mood, count: moodCount[mood] }))

    // ---- Habit-wise stats ----
    const byHabit = new Map()
    for (const log of logs) {
      const key = String(log.habit)
      if (!byHabit.has(key)) byHabit.set(key, new Set())
      byHabit.get(key).add(log.date)
    }

    const habitStats = habits.map((h) => {
      const set = byHabit.get(String(h._id)) || new Set()
      const { currentStreak, bestStreak } = computeStreaks(set)
      const daysTracked = Math.max(
        1,
        Math.ceil((Date.now() - new Date(h.createdAt).getTime()) / 86400000) + 1
      )
      const weekCompletions = weekKeys.filter((k) => set.has(k)).length
      return {
        id: h._id,
        name: h.name,
        color: h.color,
        icon: h.icon,
        totalCompletions: set.size,
        weekCompletions,
        completionRate: Math.min(100, Math.round((set.size / daysTracked) * 100)),
        currentStreak,
        bestStreak,
      }
    })

    // ---- Summary ----
    const totalCompletionsThisWeek = weeklyCompletion.reduce((a, d) => a + d.completed, 0)
    const possibleThisWeek = totalHabits * 7
    const weeklyRate = possibleThisWeek
      ? Math.round((totalCompletionsThisWeek / possibleThisWeek) * 100)
      : 0

    return res.json({
      weeklyCompletion,
      moodDistribution,
      habitStats,
      summary: {
        totalHabits,
        totalCompletionsThisWeek,
        weeklyRate,
      },
    })
  } catch (err) {
    console.error("[analytics] getWeeklyAnalytics error:", err.message)
    return res.status(500).json({ message: "Server error building analytics" })
  }
}
