import Habit from "../models/Habit.js"
import HabitLog from "../models/HabitLog.js"
import { toDateKey } from "../utils/date.js"
import { computeStreaks } from "../utils/stats.js"

// GET /api/habits
// Returns each active habit with today's completion state and streak stats.
export async function getHabits(req, res) {
  try {
    const today = toDateKey()
    const habits = await Habit.find({ user: req.userId, archived: false }).sort({ createdAt: 1 })
    const logs = await HabitLog.find({ user: req.userId, completed: true })

    // group completed date keys by habit id
    const byHabit = new Map()
    for (const log of logs) {
      const key = String(log.habit)
      if (!byHabit.has(key)) byHabit.set(key, new Set())
      byHabit.get(key).add(log.date)
    }

    const result = habits.map((h) => {
      const set = byHabit.get(String(h._id)) || new Set()
      const { currentStreak, bestStreak } = computeStreaks(set)
      const daysTracked = Math.max(
        1,
        Math.ceil((Date.now() - new Date(h.createdAt).getTime()) / 86400000) + 1
      )
      const completionRate = Math.min(100, Math.round((set.size / daysTracked) * 100))
      return {
        id: h._id,
        name: h.name,
        description: h.description,
        icon: h.icon,
        color: h.color,
        completedToday: set.has(today),
        currentStreak,
        bestStreak,
        totalCompletions: set.size,
        completionRate,
        createdAt: h.createdAt,
      }
    })

    return res.json({ habits: result })
  } catch (err) {
    console.error("[habits] getHabits error:", err.message)
    return res.status(500).json({ message: "Server error fetching habits" })
  }
}

// POST /api/habits
export async function createHabit(req, res) {
  try {
    const { name, description, icon, color } = req.body
    if (!name || !name.trim()) {
      return res.status(400).json({ message: "Habit name is required" })
    }
    const habit = await Habit.create({
      user: req.userId,
      name: name.trim(),
      description: description?.trim() || "",
      icon: icon || "target",
      color: color || "blue",
    })
    return res.status(201).json({ habit })
  } catch (err) {
    console.error("[habits] createHabit error:", err.message)
    return res.status(500).json({ message: "Server error creating habit" })
  }
}

// PUT /api/habits/:id
export async function updateHabit(req, res) {
  try {
    const { name, description, icon, color } = req.body
    const habit = await Habit.findOne({ _id: req.params.id, user: req.userId })
    if (!habit) return res.status(404).json({ message: "Habit not found" })

    if (name !== undefined) habit.name = name.trim()
    if (description !== undefined) habit.description = description.trim()
    if (icon !== undefined) habit.icon = icon
    if (color !== undefined) habit.color = color
    await habit.save()

    return res.json({ habit })
  } catch (err) {
    console.error("[habits] updateHabit error:", err.message)
    return res.status(500).json({ message: "Server error updating habit" })
  }
}

// DELETE /api/habits/:id
export async function deleteHabit(req, res) {
  try {
    const habit = await Habit.findOneAndDelete({ _id: req.params.id, user: req.userId })
    if (!habit) return res.status(404).json({ message: "Habit not found" })
    await HabitLog.deleteMany({ habit: habit._id, user: req.userId })
    return res.json({ message: "Habit deleted", id: req.params.id })
  } catch (err) {
    console.error("[habits] deleteHabit error:", err.message)
    return res.status(500).json({ message: "Server error deleting habit" })
  }
}
