import Mood, { MOODS } from "../models/Mood.js"
import { toDateKey, lastNDateKeys } from "../utils/date.js"

// POST /api/mood  { mood, date? }
// Upserts today's mood (one mood per day per user).
export async function setMood(req, res) {
  try {
    const { mood } = req.body
    const date = req.body.date || toDateKey()
    if (!MOODS.includes(mood)) {
      return res.status(400).json({ message: `mood must be one of: ${MOODS.join(", ")}` })
    }

    const doc = await Mood.findOneAndUpdate(
      { user: req.userId, date },
      { mood },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    )

    return res.json({ mood: doc.mood, date: doc.date })
  } catch (err) {
    console.error("[mood] setMood error:", err.message)
    return res.status(500).json({ message: "Server error saving mood" })
  }
}

// GET /api/mood/week
// Returns the last 7 days of moods (including today) keyed by date.
export async function getWeekMoods(req, res) {
  try {
    const keys = lastNDateKeys(7)
    const moods = await Mood.find({ user: req.userId, date: { $in: keys } })
    const map = new Map(moods.map((m) => [m.date, m.mood]))

    const week = keys.map((date) => ({ date, mood: map.get(date) || null }))
    const today = week[week.length - 1]

    return res.json({ week, today: today.mood })
  } catch (err) {
    console.error("[mood] getWeekMoods error:", err.message)
    return res.status(500).json({ message: "Server error fetching moods" })
  }
}
