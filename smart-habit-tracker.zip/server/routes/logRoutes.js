import { Router } from "express"
import { toggleLog } from "../controllers/logController.js"
import { protect } from "../middleware/auth.js"

const router = Router()

router.use(protect)
router.post("/toggle", toggleLog)

export default router
