import { Router } from "express"
import { getWeeklyAnalytics } from "../controllers/analyticsController.js"
import { protect } from "../middleware/auth.js"

const router = Router()

router.use(protect)
router.get("/weekly", getWeeklyAnalytics)

export default router
