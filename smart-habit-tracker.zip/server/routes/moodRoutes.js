import { Router } from "express"
import { setMood, getWeekMoods } from "../controllers/moodController.js"
import { protect } from "../middleware/auth.js"

const router = Router()

router.use(protect)
router.post("/", setMood)
router.get("/week", getWeekMoods)

export default router
