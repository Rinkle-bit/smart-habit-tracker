import "dotenv/config"
import express from "express"
import cors from "cors"

import { connectDB } from "./config/db.js"
import authRoutes from "./routes/authRoutes.js"
import habitRoutes from "./routes/habitRoutes.js"
import logRoutes from "./routes/logRoutes.js"
import moodRoutes from "./routes/moodRoutes.js"
import analyticsRoutes from "./routes/analyticsRoutes.js"

const app = express()

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    credentials: true,
  })
)
app.use(express.json())

// Health check
app.get("/api/health", (req, res) => res.json({ status: "ok" }))

// Routes
app.use("/api/auth", authRoutes)
app.use("/api/habits", habitRoutes)
app.use("/api/logs", logRoutes)
app.use("/api/mood", moodRoutes)
app.use("/api/analytics", analyticsRoutes)

// 404 fallback
app.use((req, res) => res.status(404).json({ message: "Route not found" }))

const PORT = process.env.PORT || 5000

connectDB().then(() => {
  app.listen(PORT, () => console.log(`[server] API running on http://localhost:${PORT}`))
})
